To show the carriage bringing a log through the mill, you need to layer several sprites in order.

- The carriage and log sprite is (32*5=160px) x (64px). 
- Each log can be cut three times. The three columns of `carriage.png` show the three different times the log is cut.
- The top row of `carriage.png` shows the carriage with un-cut log ("bg-uncut").
- The second row of `carriage.png` shows the background of the cut log ("bg-cut").
- The third row of `carriage.png` shows the foreground of the cut log ("fg-cut").


The sprites/tiles should be ordered like this (bottom to top Z-order):
- Saw frame background, floor (`sawmill.png`)
- Carriage/log background sprite (bg-uncut/bg-cut) from `carriage.png`
- Saw blade (`sawmill-blade.png`)
- Carriage/log foreground sprite (fg-cut) from `carriage.png`
- Carriage wheels `carriage-wheels.png`; these can be animated independently to show the carriage rolling down the tracks
- Saw frame foreground
- Sawmill shadow, roof, etc. as desired

The idea is, as the carriage passes through the saw, you "wipe" from bg-uncut to bg-cut. For example, if the carriage was at 0px and the left edge of the saw was at x = 100px, you would: 
- crop bg-uncut from 0:100px and draw at x=0px, 
- crop bg-cut from 100:160px and draw at x=100px, 
- draw `sawmill-blade.png` at x = 100px, 
- draw fg-cut at x = 0 px, 
- draw `carriage-wheels.png` at x = 0 px

There is a rough example of this in the Tiled <https://www.mapeditor.org> map `sawmill.tmx`. I can't show the smooth movement/cropping of the carriage in Tiled, but hopefully you get the idea.